
const notificationButton = document.getElementById("notificationButton");

notificationButton.addEventListener("click", function () {
    alert("No new notifications.");
});
