const goBackButton = document.getElementById("goBackButton");
const notificationButton = document.getElementById("notificationButton");


// Return to the Completed Orders page
goBackButton.addEventListener("click", function () {
    window.location.href = "sales-report-completed-orders.html";
});


// Notification button
notificationButton.addEventListener("click", function () {
    alert("No new notifications.");
});